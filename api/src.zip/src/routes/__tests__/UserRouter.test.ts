import request from "supertest";
import app from "../../config/server/server";
import { UserComponent } from "@/components";

const baseUrl = "/v1/users";

// Mock global de TODOS los componentes usados por los routers
jest.mock("@/components", () => {
  let users = new Map<string, any>();
  let idCounter = 1;

  const hashPassword = (password: string) => `hashed-${password}`;

  // 🟢 MOCK COMPLETO DE UserComponent (EL QUE TESTEAMOS)
  const UserComponent = {
    async findAll(req: any, res: any) {
      return res.status(200).json(Array.from(users.values()));
    },

    async findOne(req: any, res: any) {
      const { id } = req.params;
      const user = users.get(id);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      return res.status(200).json(user);
    },

    async create(req: any, res: any) {
      const { email, password, name } = req.body;

      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      const emailExists = Array.from(users.values()).some(
        (u) => u.email === email
      );

      if (emailExists) {
        return res.status(400).json({ message: "Email already exists" });
      }

      const id = String(idCounter++);
      const newUser = {
        _id: id,
        name,
        email,
        password: hashPassword(password),
      };

      users.set(id, newUser);

      return res.status(201).json(newUser);
    },

    async update(req: any, res: any) {
      const { id } = req.params;
      const { name, email } = req.body;

      const user = users.get(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updated = {
        ...user,
        name: name ?? user.name,
        email: email ?? user.email,
      };

      users.set(id, updated);

      return res.status(200).json(updated);
    },

    async remove(req: any, res: any) {
      const { id } = req.params;

      if (!users.has(id)) {
        return res.status(404).json({ message: "User not found" });
      }

      users.delete(id);
      return res.status(204).send();
    },

    __clear() {
      users.clear();
      idCounter = 1;
    },
  };

  // 🟡 MOCK NECESARIO PARA QUE AuthRouter NO ROMPA
  const AuthComponent = {
    login: jest.fn((req: any, res: any) =>
      res.status(200).json({ token: "fake-token" })
    ),
  };

  // 🟡 MOCK NECESARIO PARA QUE AboutMeRouter NO ROMPA
  const AboutMeComponent = {
    findAll: jest.fn((req: any, res: any) =>
      res.status(200).json({ about: "ok" })
    ),
  };

  // 🟡 MOCK NECESARIO PARA ProjectsRouter (OJO: con "s")
  const ProjectsComponent = {
    findAll: jest.fn((req: any, res: any) =>
      res.status(200).json([])
    ),
    create: jest.fn((req: any, res: any) =>
      res.status(201).json({ _id: "1", ...req.body })
    ),
  };

  return { UserComponent, AuthComponent, AboutMeComponent, ProjectsComponent };
});

const mockedUserComponent = UserComponent as any;

describe("UserRouter", () => {
  beforeEach(() => {
    if (mockedUserComponent.__clear) {
      mockedUserComponent.__clear();
    }
  });

  test("GET /v1/users/:id devuelve 200 y el usuario cuando existe", async () => {
    const payload = {
      name: "Alice",
      email: `get_${Date.now()}@test.com`,
      password: "secret123",
    };

    const createRes = await request(app)
      .post(baseUrl)
      .send(payload)
      .expect(201);

    const user = createRes.body;

    const res = await request(app)
      .get(`${baseUrl}/${user._id}`)
      .expect(200);

    expect(res.body._id).toBe(user._id);
    expect(res.body.email).toBe(payload.email);
  });

  test("GET /v1/users/:id devuelve 404 cuando el usuario no existe", async () => {
    const fakeId = "9999";

    const res = await request(app)
      .get(`${baseUrl}/${fakeId}`)
      .expect(404);

    expect(res.body).toHaveProperty("message", "User not found");
  });

  test("POST /v1/users crea un usuario válido y hashea el password", async () => {
    const payload = {
      name: "Bob",
      email: `create_${Date.now()}@test.com`,
      password: "password123",
    };

    const res = await request(app)
      .post(baseUrl)
      .send(payload)
      .expect(201);

    expect(res.body).toHaveProperty("_id");
    expect(res.body.email).toBe(payload.email);
    expect(res.body.password).toBe(`hashed-${payload.password}`);
  });

  test("POST /v1/users devuelve 400 si el email ya existe", async () => {
    const email = `dup_${Date.now()}@test.com`;

    const firstUser = { name: "A", email, password: "123" };
    const secondUser = { name: "B", email, password: "456" };

    await request(app).post(baseUrl).send(firstUser).expect(201);

    const res = await request(app)
      .post(baseUrl)
      .send(secondUser)
      .expect(400);

    expect(res.body.message).toBe("Email already exists");
  });

  test("POST /v1/users devuelve 400 si falta email", async () => {
    const payload = {
      name: "NoMail",
      password: "123",
    };

    const res = await request(app)
      .post(baseUrl)
      .send(payload)
      .expect(400);

    expect(res.body.message).toBe("Email is required");
  });
});