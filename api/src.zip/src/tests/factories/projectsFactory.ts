
import { ProjectFixture } from "../fixtures/projects";

let projectCounter = 1;

export function resetProjectFactory() {
  projectCounter = 1;
}

export function buildProject(
  overrides: Partial<ProjectFixture> = {}
): ProjectFixture {
  const id = overrides.id ?? `project-${projectCounter++}`;
  const base: ProjectFixture = {
    id,
    title: overrides.title ?? `Proyecto ${id}`,
    description: overrides.description ?? `Descripción del ${id}`,
    technologies: overrides.technologies ?? ["Node.js", "TypeScript"],
    repoUrl:
      overrides.repoUrl ?? `https://github.com/example/${id}-repo`,
    liveUrl:
      overrides.liveUrl ?? `https://example.com/${id}`,
  };

  return base;
}

export function buildProjects(
  count: number,
  overrides: Partial<ProjectFixture> = {}
): ProjectFixture[] {
  return Array.from({ length: count }).map(() => buildProject(overrides));
}