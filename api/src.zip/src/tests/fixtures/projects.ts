
export type ProjectFixture = {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  repoUrl?: string;
  liveUrl?: string;
};
export const validProject: ProjectFixture = {
  id: "project-1",
  title: "Proyecto de prueba",
  description: "Proyecto válido para pruebas de API.",
  technologies: ["Node.js", "TypeScript"],
  repoUrl: "https://github.com/example/project-1",
  liveUrl: "https://example.com/project-1",
};

export const invalidProjects: {
  noTitle: Partial<ProjectFixture>;
  noDescription: Partial<ProjectFixture>;
  noTechnologies: Partial<ProjectFixture>;
} = {
  noTitle: {
    id: "invalid-1",
    // title falta
    description: "Falta el título",
    technologies: ["Node.js"],
  },
  noDescription: {
    id: "invalid-2",
    title: "Sin descripción",
    // description falta
    technologies: ["Node.js"],
  },
  noTechnologies: {
    id: "invalid-3",
    title: "Sin tecnologías",
    description: "No tiene lista de tecnologías",
    technologies: [],
  },
};
export const sampleProjects: ProjectFixture[] = [
  {
    id: "project-2",
    title: "API Portfolio",
    description: "Backend del portfolio personal.",
    technologies: ["Node.js", "Express"],
    repoUrl: "https://github.com/example/api-portfolio",
    liveUrl: "https://api.example.com",
  },
  {
    id: "project-3",
    title: "UI Portfolio",
    description: "Frontend del portfolio personal.",
    technologies: ["React", "TypeScript"],
    repoUrl: "https://github.com/example/ui-portfolio",
    liveUrl: "https://portfolio.example.com",
  },
  {
    id: "project-4",
    title: "Panel Admin",
    description: "Dashboard de administración.",
    technologies: ["React", "Node.js"],
    repoUrl: "https://github.com/example/admin-panel",
    liveUrl: "https://admin.example.com",
  },
];